import java.sql.*;
class Stmt3 
{
	public static void main(String[] args) 
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","surya","surya");

			CallableStatement cs = con.prepareCall("{call proc1(?,?,?)}");
			cs.setInt(1,1000);
			cs.setInt(2,2000);
			cs.registerOutParameter(1,Types.INTEGER);
			cs.registerOutParameter(2,Types.INTEGER);
			cs.registerOutParameter(3,Types.INTEGER);
			int i = cs.executeUpdate();
			System.out.println(cs.getInt(1));
			System.out.println(cs.getInt(2));
			System.out.println(cs.getInt(3));
			System.out.println(i);
			cs.close();
			con.close();
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
		
	}
}