import java.sql.*;
class StmtPrep
{
	public static void main(String[] args) 
	{
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:oci:@localhost","surya","surya");

			long t1,t2,diff;
			String vsql = "insert into tt values(?,?,?)";
			PreparedStatement pstmt = con.prepareStatement(vsql);
			t1 = System.currentTimeMillis();
			for(int i=1;i<=100;i++)
			{
				pstmt.setInt(1,i);
				pstmt.setInt(2,i);
				pstmt.setInt(3,i);
				
				pstmt.executeUpdate();
			}

			t2 = System.currentTimeMillis();
			diff = t2 - t1;
			System.out.println("Diff --> "+diff);
			con.close();
		}
		catch(Exception e){
			System.out.println("Error --> "+e);
		}
	}
}