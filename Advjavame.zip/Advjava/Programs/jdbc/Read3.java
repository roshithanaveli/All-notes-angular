import java.sql.*;
class Read3
{
	public static void main(String[] args) 
	{
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:oci:@localhost","surya","surya");
			Statement stmt = con.createStatement(
			ResultSet.TYPE_SCROLL_SENSITIVE,	
			ResultSet.CONCUR_UPDATABLE);

			String str = "select sid,sname,age,address from student";

			ResultSet rs = stmt.executeQuery(str);

			rs.last();
			
			//rs.updateString("sid","5");
			//rs.updateString("sname","e");
			//rs.updateString("age","24");
			//rs.updateString("address","sf");

			rs.deleteRow();
		}
		catch(Exception e){
			System.out.println("Error");
			System.out.println(e);
		}
	}
}