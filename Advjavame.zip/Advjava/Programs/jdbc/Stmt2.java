import java.sql.*;
class Stmt2
{
	public static void main(String[] args) 
	{
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:oci:@localhost","surya","surya");

			String vsql = "update student set age = ? where sid = ?";

			PreparedStatement pst = con.prepareStatement(vsql);

			pst.setInt(1,25);
			pst.setInt(2,1);

			pst.executeUpdate();

			System.out.println("Executed --> "+vsql);
			
			pst.setInt(1,26);
			pst.setInt(2,2);

			pst.executeUpdate();

			System.out.println("Executed --> "+vsql);

			pst.close();
			con.close();
		}
		catch(Exception e){
			System.out.println("Error --> "+e);
		}
	}
}