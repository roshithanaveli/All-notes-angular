//demo on scroll sensitive resultset
import java.sql.*;
class RSDemo
{
	public static void main(String[] args) 
	{
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:oci:@localhost","alfa","alfa");

			Statement stmt = con.createStatement(
				ResultSet.TYPE_SCROLL_SENSITIVE,
				ResultSet.CONCUR_UPDATABLE);
			
			String str = "select uname,password from login";

			ResultSet rs = stmt.executeQuery(str);

			rs.moveToInsertRow();

			System.out.println("Current Row --> "+rs.getRow());

			rs.updateString("uname","d");
			rs.updateString("password","xyz");

			rs.insertRow();

			stmt.close();
			con.close();
		}
		catch(Exception e){
			System.out.println(e);
		}
	}
}