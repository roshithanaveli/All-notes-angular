//connecting to ms access
import java.sql.*;
class MSConn
{
	public static void main(String[] args) 
	{
		try{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			Connection con = DriverManager.getConnection("jdbc:odbc:msdsn");
			System.out.println("Connected .....");
			con.close();
		}catch(Exception e){}
	}
}