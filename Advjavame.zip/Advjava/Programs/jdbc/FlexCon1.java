import java.sql.*;
class FlexCon1
{
	public static void main(String[] args) 
	{
		String drv = System.getProperty("drv");
		String url = System.getProperty("url");
		String un = System.getProperty("un");
		String pw = System.getProperty("pw");
		try{
			Class.forName(drv);
			Connection con = DriverManager.getConnection(url,un,pw);
			System.out.println("Connected ......");
		}catch(Exception e){}
	}
}