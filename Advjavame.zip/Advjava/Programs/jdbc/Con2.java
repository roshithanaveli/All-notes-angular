//demo on jdbc type2 driver
import java.sql.*;
class Con2
{
	public static void main(String[] args) 
	{
		Connection con = null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:oci:@localhost","surya","surya");
			System.out.println("Connected ........");
			Thread.sleep(500);
			con.close();
			System.out.println("Disconnected ........");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}