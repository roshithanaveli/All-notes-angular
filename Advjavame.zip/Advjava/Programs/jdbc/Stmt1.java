//Executing a statement
import java.sql.*;
class Stmt1
{
	public static void main(String[] args) 
	{
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:oci:@localhost","alfa","alfa");
			Statement stmt = con.createStatement();
			String vsql = "create table login (uname varchar2(15) primary key, password varchar2(15))";
			stmt.execute(vsql);
			System.out.println("Executed ---> "+vsql);
			stmt.close();
			con.close();
		}
		catch(Exception e){
			System.out.println("Error");
		}
	}
}