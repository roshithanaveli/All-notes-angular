//Demo on Stored Procedures
import java.sql.*;
class StoredProc
{
	public static void main(String[] args) 
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","ipad","ipad");

			String str = "{? = call fun1(?,?)}";
			
			CallableStatement cs = con.prepareCall(str);

			cs.setInt(2,1000);
			cs.setInt(3,2000);

			cs.registerOutParameter(1,Types.INTEGER);
//			cs.registerOutParameter(2,Types.INTEGER);
//			cs.registerOutParameter(3,Types.INTEGER);

			cs.executeUpdate();

			System.out.println(cs.getInt(1));
//			System.out.println(cs.getInt(2));
//			System.out.println(cs.getInt(3));

			cs.close();
			con.close();

		}
		catch (Exception e)
		{
			System.out.println(e);
		}
	}
}