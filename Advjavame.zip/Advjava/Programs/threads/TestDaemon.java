class TestDaemon extends Thread
{
	static boolean b2;
	int j ;
	public void run()
	{
		for(int i=1;i<10000;i++)
		{
			j=i;
			System.out.println(j);
		}
	 }
		public static boolean getState1(boolean b3)
		{
			b2 = b3;

			return b2;
		}

	

	public static void main(String[] args) 
	{
		boolean b = Boolean.valueOf(args[0]);
		getState1(b);

		TestDaemon t = new TestDaemon();
		