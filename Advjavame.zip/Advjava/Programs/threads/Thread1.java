class ThrYield extends Thread 
{
	static boolean b = true;
	public void run()
	{
		for(int i=1;i<4;i++)
		{
			System.out.println(i);
			if(b) {
				b = false;
				Thread.yield();
			}
		}
	}
}
class Thread1
{
	public static void main(String[] args) 
	{
		ThrYield t1 = new ThrYield();
		ThrYield t2 = new ThrYield();
		ThrYield t3 = new ThrYield();
		t1.start();
		t2.start();
		t3.start();
	}
}