// Using thread groups
class TGroups
{
	public static void main(String[] args) throws Exception
	{
		Reservation res = new Reservation();
		Cancellation can = new Cancellation();

		//create a threadgroup with name
		ThreadGroup tg = new ThreadGroup("Reservation Group");

		//create 2 threads and add them to thread group
		Thread t1 = new Thread(tg,res,"First Thread");
		Thread t2 = new Thread(tg,res,"Second Thread");

		//create another thread group as a child to tg
		ThreadGroup tg1 = new ThreadGroup(tg,"Cancellation Group");

		//create 2 threads and add them to second thread group
		Thread t3 = new Thread(tg1,can,"Third Thread");
		Thread t4 = new Thread(tg1,can,"Forth Thread");

		System.out.println("No of threads in this group : "+tg.activeCount());

		//find parant group of tg1
		System.out.println("Parent of TG1 : "+tg1.getParent());

		//know the thread group of t1 and t3
		System.out.println("Thread group of t1 : "+t1.getThreadGroup());
		System.out.println("Thread group of t3 : "+t3.getThreadGroup());

		System.out.println(t1.getPriority());
		System.out.println(t3.getPriority());
		//start the threads
		t1.start();
		t3.start();
		t2.start();
		t4.start();
		System.out.println("No of threads in this group : "+tg.activeCount());
		System.out.println(Thread.currentThread());
	}
}
class Reservation extends Thread
{
	public void run()
	{
		try{
		Thread.sleep(1000);
		}catch(Exception e){}
		System.out.println(" I am Reservation thread ");
	}
}
class Cancellation extends Thread
{
	public void run()
	{
		try{
		Thread.sleep(1000);
		}catch(Exception e){}
		System.out.println(" I am Cancellation thread ");
	}
}