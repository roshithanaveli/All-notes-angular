//TWO THREADS ACTING ON SAME OBJECT
class Reserve implements Runnable
{
	int available = 1;
	int wanted;
	Reserve(int i)
	{
		wanted = i;
	}
	public void run()
	{
	synchronized(this){	
			System.out.println("No. of berths available = "+available);
			String name = Thread.currentThread().getName();
	
			if(available >= wanted)
			{
				System.out.println(wanted+" berths alloted for "+name);
				try{
					Thread.sleep(6000);
					available = available - wanted;
					System.out.println(name+" Completed Process ");
				}
				catch(InterruptedException ie){}
			}
			else
				System.out.println("Sorry, berth not available for "+name);
		}
	}
}
class Safe
{
	public static void main(String[] args) 
	{
		// Create Reserve Object and specify 1 berth is wanted
		Reserve obj = new Reserve(1);
		// Create two threads and attach to obj
		Thread t1 = new Thread(obj);
		Thread t2 = new Thread(obj);
		// Set names for threads
		t1.setName("Person1");
		t2.setName("Person2");
		//Start threads
		t1.start();
		t2.start();
	}
}