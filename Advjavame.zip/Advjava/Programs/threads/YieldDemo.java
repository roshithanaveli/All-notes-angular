//demo on yield method
class YieldDemo implements Runnable
{
	boolean b = true;
	public void run()
	{
		for(int i=1;i<7;i++)
		{
			System.out.println(i);
			if(b)
			{
				b = false;
				Thread.yield();
			}
		}
	}
	public static void main(String[] args) 
	{
		YieldDemo obj1 = new YieldDemo();
		YieldDemo obj2 = new YieldDemo();
		YieldDemo obj3 = new YieldDemo();
		
		Thread t1 = new Thread(obj1);
		Thread t2 = new Thread(obj2);
		Thread t3 = new Thread(obj3);

		t1.start();
		t2.start();
		t3.start();
	}
}