//Demo on wait method
class ThreadA {
	public static void main(String [] args) {
		ThreadB b = new ThreadB();
		b.start();
		synchronized(b){
			try {
				System.out.println(Thread.currentThread());
				System.out.println("Waiting for b to complete...");
				b.wait();
			} catch (Exception e) {}
			System.out.println("Total is: " + b.total);
		}
	}
}
class ThreadB extends Thread {
	int total;
	public void run() {
		synchronized(this) {
			for(int i=0;i<10;i++) {
				total += i;
			}
			//notify();
		}
	}
}